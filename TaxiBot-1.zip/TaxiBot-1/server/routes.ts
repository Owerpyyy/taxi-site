import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertDriverSchema, insertBookingSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Driver routes
  app.get("/api/drivers", async (req, res) => {
    try {
      const drivers = await storage.getAllDrivers();
      res.json(drivers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch drivers" });
    }
  });

  app.get("/api/drivers/online", async (req, res) => {
    try {
      const drivers = await storage.getOnlineDrivers();
      res.json(drivers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch online drivers" });
    }
  });

  app.post("/api/drivers", async (req, res) => {
    try {
      const driverData = insertDriverSchema.parse(req.body);
      const driver = await storage.createDriver(driverData);
      res.status(201).json(driver);
      
      // Broadcast driver registration to all clients
      broadcastToAll({ type: "driver_registered", data: driver });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid driver data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create driver" });
      }
    }
  });

  app.patch("/api/drivers/:id/status", async (req, res) => {
    try {
      const { id } = req.params;
      const { online } = req.body;
      
      const driver = await storage.updateDriverOnlineStatus(id, online);
      if (!driver) {
        return res.status(404).json({ message: "Driver not found" });
      }
      
      res.json(driver);
      
      // Broadcast status change to all clients
      broadcastToAll({ type: "driver_status_changed", data: driver });
    } catch (error) {
      res.status(500).json({ message: "Failed to update driver status" });
    }
  });

  // Booking routes
  app.get("/api/bookings", async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  app.get("/api/bookings/pending", async (req, res) => {
    try {
      const bookings = await storage.getBookingsByStatus("pending");
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pending bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(bookingData);
      res.status(201).json(booking);
      
      // Broadcast new booking to online drivers
      broadcastToAll({ type: "new_booking", data: booking });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create booking" });
      }
    }
  });

  app.patch("/api/bookings/:id/accept", async (req, res) => {
    try {
      const { id } = req.params;
      const { driverId } = req.body;
      
      const booking = await storage.updateBookingStatus(id, "accepted", driverId);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
      
      // Broadcast booking acceptance to all clients
      broadcastToAll({ type: "booking_accepted", data: booking });
    } catch (error) {
      res.status(500).json({ message: "Failed to accept booking" });
    }
  });

  app.patch("/api/bookings/:id/complete", async (req, res) => {
    try {
      const { id } = req.params;
      
      const booking = await storage.updateBookingStatus(id, "completed");
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
      
      // Broadcast booking completion to all clients
      broadcastToAll({ type: "booking_completed", data: booking });
    } catch (error) {
      res.status(500).json({ message: "Failed to complete booking" });
    }
  });

  app.delete("/api/bookings/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteBooking(id);
      
      if (!success) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.status(204).send();
      
      // Broadcast booking deletion to all clients
      broadcastToAll({ type: "booking_deleted", data: { id } });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete booking" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    
    ws.on('close', () => {
      clients.delete(ws);
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  function broadcastToAll(message: any) {
    const messageStr = JSON.stringify(message);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  return httpServer;
}
