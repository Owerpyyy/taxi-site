import { drivers, bookings, users, type Driver, type Booking, type InsertDriver, type InsertBooking, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User methods (for compatibility)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Driver methods
  getDriver(id: string): Promise<Driver | undefined>;
  getDriverByPhone(phone: string): Promise<Driver | undefined>;
  createDriver(driver: InsertDriver): Promise<Driver>;
  updateDriverOnlineStatus(id: string, online: boolean): Promise<Driver | undefined>;
  getOnlineDrivers(): Promise<Driver[]>;
  getAllDrivers(): Promise<Driver[]>;
  
  // Booking methods
  getBooking(id: string): Promise<Booking | undefined>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: string, status: string, driverId?: string): Promise<Booking | undefined>;
  getBookingsByStatus(status: string): Promise<Booking[]>;
  getBookingsByDriver(driverId: string): Promise<Booking[]>;
  getAllBookings(): Promise<Booking[]>;
  deleteBooking(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Driver methods
  async getDriver(id: string): Promise<Driver | undefined> {
    const [driver] = await db.select().from(drivers).where(eq(drivers.id, id));
    return driver || undefined;
  }

  async getDriverByPhone(phone: string): Promise<Driver | undefined> {
    const [driver] = await db.select().from(drivers).where(eq(drivers.phone, phone));
    return driver || undefined;
  }

  async createDriver(insertDriver: InsertDriver): Promise<Driver> {
    const [driver] = await db
      .insert(drivers)
      .values(insertDriver)
      .returning();
    return driver;
  }

  async updateDriverOnlineStatus(id: string, online: boolean): Promise<Driver | undefined> {
    const [driver] = await db
      .update(drivers)
      .set({ online })
      .where(eq(drivers.id, id))
      .returning();
    return driver || undefined;
  }

  async getOnlineDrivers(): Promise<Driver[]> {
    return await db.select().from(drivers).where(eq(drivers.online, true));
  }

  async getAllDrivers(): Promise<Driver[]> {
    return await db.select().from(drivers);
  }

  // Booking methods
  async getBooking(id: string): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking || undefined;
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    // Calculate estimated price based on distance (simplified)
    const estimatedPrice = "280.00"; // Would normally calculate based on addresses
    
    const [booking] = await db
      .insert(bookings)
      .values({
        ...insertBooking,
        estimatedPrice,
      })
      .returning();
    return booking;
  }

  async updateBookingStatus(id: string, status: string, driverId?: string): Promise<Booking | undefined> {
    const updateData: any = { status };
    if (driverId) {
      updateData.driverId = driverId;
    }
    
    const [booking] = await db
      .update(bookings)
      .set(updateData)
      .where(eq(bookings.id, id))
      .returning();
    return booking || undefined;
  }

  async getBookingsByStatus(status: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.status, status as any));
  }

  async getBookingsByDriver(driverId: string): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.driverId, driverId));
  }

  async getAllBookings(): Promise<Booking[]> {
    return await db.select().from(bookings);
  }

  async deleteBooking(id: string): Promise<boolean> {
    const result = await db.delete(bookings).where(eq(bookings.id, id));
    return result.rowCount > 0;
  }
}

export const storage = new DatabaseStorage();
