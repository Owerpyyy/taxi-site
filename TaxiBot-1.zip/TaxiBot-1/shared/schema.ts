import { sql, relations } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, decimal, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const fuelTypeEnum = pgEnum("fuel_type", ["petrol", "diesel", "propane", "methane", "electric"]);
export const bookingStatusEnum = pgEnum("booking_status", ["pending", "accepted", "in_progress", "completed", "cancelled"]);

export const drivers = pgTable("drivers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  carBrand: text("car_brand").notNull(),
  carNumber: text("car_number").notNull().unique(),
  carColor: text("car_color").notNull(),
  fuelType: fuelTypeEnum("fuel_type").notNull(),
  online: boolean("online").default(false).notNull(),
  rating: decimal("rating", { precision: 3, scale: 1 }).default("5.0").notNull(),
  totalRatings: decimal("total_ratings").default("0").notNull(),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const bookings = pgTable("bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fromAddress: text("from_address").notNull(),
  toAddress: text("to_address").notNull(),
  bookingDate: text("booking_date").notNull(),
  bookingTime: text("booking_time").notNull(),
  clientName: text("client_name").notNull(),
  clientPhone: text("client_phone").notNull(),
  status: bookingStatusEnum("status").default("pending").notNull(),
  driverId: varchar("driver_id").references(() => drivers.id),
  estimatedPrice: decimal("estimated_price", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").default(sql`CURRENT_TIMESTAMP`).notNull(),
});

export const driversRelations = relations(drivers, ({ many }) => ({
  bookings: many(bookings),
}));

export const bookingsRelations = relations(bookings, ({ one }) => ({
  driver: one(drivers, {
    fields: [bookings.driverId],
    references: [drivers.id],
  }),
}));

export const insertDriverSchema = createInsertSchema(drivers).omit({
  id: true,
  online: true,
  rating: true,
  totalRatings: true,
  createdAt: true,
});

export const insertBookingSchema = createInsertSchema(bookings).omit({
  id: true,
  status: true,
  driverId: true,
  estimatedPrice: true,
  createdAt: true,
});

export type InsertDriver = z.infer<typeof insertDriverSchema>;
export type Driver = typeof drivers.$inferSelect;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type Booking = typeof bookings.$inferSelect;

// User schema remains for compatibility
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
