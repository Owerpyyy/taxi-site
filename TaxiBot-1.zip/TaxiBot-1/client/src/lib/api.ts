export const API_BASE_URL = "";

export const apiEndpoints = {
  drivers: {
    list: "/api/drivers",
    online: "/api/drivers/online",
    create: "/api/drivers",
    updateStatus: (id: string) => `/api/drivers/${id}/status`,
  },
  bookings: {
    list: "/api/bookings",
    pending: "/api/bookings/pending",
    create: "/api/bookings",
    accept: (id: string) => `/api/bookings/${id}/accept`,
    complete: (id: string) => `/api/bookings/${id}/complete`,
    delete: (id: string) => `/api/bookings/${id}`,
  },
};
