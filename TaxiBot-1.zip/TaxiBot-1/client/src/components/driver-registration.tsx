import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDriverSchema } from "@shared/schema";
import { type InsertDriver, type Driver } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";

interface DriverRegistrationProps {
  currentDriver: Driver | null;
  onDriverRegistered: (driver: Driver) => void;
}

export default function DriverRegistration({ currentDriver, onDriverRegistered }: DriverRegistrationProps) {
  const { toast } = useToast();

  const form = useForm<InsertDriver>({
    resolver: zodResolver(insertDriverSchema),
    defaultValues: {
      name: "",
      phone: "",
      carBrand: "",
      carNumber: "",
      carColor: "",
      fuelType: "petrol",
    },
  });

  const createDriverMutation = useMutation({
    mutationFn: async (data: InsertDriver) => {
      const response = await apiRequest('POST', '/api/drivers', data);
      return response.json();
    },
    onSuccess: (driver: Driver) => {
      onDriverRegistered(driver);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось зарегистрировать водителя. Возможно, телефон уже используется.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertDriver) => {
    createDriverMutation.mutate(data);
  };

  // Don't show registration form if driver is already registered
  if (currentDriver) {
    return (
      <div className="bg-white rounded-2xl card-shadow-lg p-8">
        <div className="flex items-center mb-6">
          <div className="bg-green-100 p-3 rounded-xl mr-4">
            <i className="fas fa-check text-green-600 text-xl"></i>
          </div>
          <h3 className="text-2xl font-semibold text-gray-800">Водитель зарегистрирован</h3>
        </div>
        
        <div className="bg-gray-50 rounded-xl p-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Имя водителя</p>
              <p className="font-semibold text-gray-800">{currentDriver.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Телефон</p>
              <p className="font-semibold text-gray-800">{currentDriver.phone}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Автомобиль</p>
              <p className="font-semibold text-gray-800">{currentDriver.carBrand}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Номер</p>
              <p className="font-semibold text-gray-800">{currentDriver.carNumber}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl card-shadow-lg p-8">
      <div className="flex items-center mb-6">
        <div className="bg-taxi-purple bg-opacity-10 p-3 rounded-xl mr-4">
          <i className="fas fa-user-plus text-taxi-purple text-xl"></i>
        </div>
        <h3 className="text-2xl font-semibold text-gray-800">Регистрация водителя</h3>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-driver-registration">
          {/* Personal Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-user text-taxi-purple mr-2"></i>Имя водителя
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Ваше полное имя"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-driver-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-phone text-taxi-purple mr-2"></i>Телефон
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="tel"
                      placeholder="+7 (999) 123-45-67"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-driver-phone"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Car Information */}
          <div className="bg-gray-50 rounded-xl p-6">
            <h4 className="font-semibold text-gray-800 mb-4">
              <i className="fas fa-car text-taxi-purple mr-2"></i>Информация об автомобиле
            </h4>
            <div className="grid md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="carBrand"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold text-gray-700">Марка и модель</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Toyota Camry"
                        className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                        data-testid="input-car-brand"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="carNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold text-gray-700">Номер автомобиля</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="А123БВ777"
                        className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                        data-testid="input-car-number"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="carColor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold text-gray-700">Цвет автомобиля</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        placeholder="Белый"
                        className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                        data-testid="input-car-color"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="fuelType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold text-gray-700">Тип топлива</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                                       data-testid="select-fuel-type">
                          <SelectValue placeholder="Выберите тип" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="petrol">Бензин</SelectItem>
                        <SelectItem value="diesel">Дизель</SelectItem>
                        <SelectItem value="propane">Пропан</SelectItem>
                        <SelectItem value="methane">Метан</SelectItem>
                        <SelectItem value="electric">Электро</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={createDriverMutation.isPending}
            className="w-full gradient-bg text-white py-4 rounded-xl font-semibold text-lg hover:opacity-90 transition-all duration-300 shadow-lg transform hover:scale-105"
            data-testid="button-submit-driver-registration"
          >
            <i className="fas fa-check mr-2"></i>
            {createDriverMutation.isPending ? "Регистрация..." : "Зарегистрироваться как водитель"}
          </Button>
        </form>
      </Form>
    </div>
  );
}
