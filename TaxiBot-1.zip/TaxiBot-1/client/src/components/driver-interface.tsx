import DriverRegistration from "./driver-registration";
import TripRequests from "./trip-requests";
import { useQuery } from "@tanstack/react-query";
import { type Driver, type Booking } from "@shared/schema";
import { useState, useEffect } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function DriverInterface() {
  const [currentDriver, setCurrentDriver] = useState<Driver | null>(null);
  const { toast } = useToast();

  const { data: bookings = [], refetch: refetchBookings } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      const message = JSON.parse(lastMessage);
      if (["new_booking", "booking_accepted", "booking_completed"].includes(message.type)) {
        refetchBookings();
      }
    }
  }, [lastMessage, refetchBookings]);

  const handleDriverRegistered = (driver: Driver) => {
    setCurrentDriver(driver);
    localStorage.setItem('currentDriver', JSON.stringify(driver));
    toast({
      title: "Регистрация успешна!",
      description: "Теперь вы можете начать работу.",
    });
  };

  const toggleDriverStatus = async () => {
    if (!currentDriver) return;

    try {
      const newStatus = !currentDriver.online;
      await apiRequest('PATCH', `/api/drivers/${currentDriver.id}/status`, { online: newStatus });
      
      const updatedDriver = { ...currentDriver, online: newStatus };
      setCurrentDriver(updatedDriver);
      localStorage.setItem('currentDriver', JSON.stringify(updatedDriver));
      
      toast({
        title: newStatus ? "Вы в сети" : "Вы оффлайн",
        description: newStatus ? "Теперь вы будете получать заявки" : "Вы перестанете получать заявки",
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось изменить статус",
        variant: "destructive",
      });
    }
  };

  // Load driver from localStorage on mount
  useEffect(() => {
    const savedDriver = localStorage.getItem('currentDriver');
    if (savedDriver) {
      setCurrentDriver(JSON.parse(savedDriver));
    }
  }, []);

  const pendingBookings = bookings.filter(booking => booking.status === "pending");
  const activeBookings = bookings.filter(
    booking => booking.status === "accepted" && booking.driverId === currentDriver?.id
  );

  return (
    <div className="container mx-auto px-4 py-8 animate-fadeIn">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Панель водителя</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Управляйте своими поездками и статусом работы
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Driver Registration */}
          <div className="lg:col-span-2">
            <DriverRegistration 
              currentDriver={currentDriver} 
              onDriverRegistered={handleDriverRegistered}
            />
          </div>

          {/* Driver Status */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl card-shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-6">Статус работы</h3>
              
              <div className="text-center" data-testid="container-driver-status">
                {currentDriver ? (
                  <div className="space-y-4">
                    <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto text-white text-2xl ${
                      currentDriver.online 
                        ? "bg-gradient-to-r from-green-500 to-green-600" 
                        : "bg-gradient-to-r from-gray-500 to-gray-600"
                    }`}>
                      <i className="fas fa-car"></i>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 text-lg" data-testid="text-driver-name">
                        {currentDriver.name}
                      </h4>
                      <p className="text-sm text-gray-600" data-testid="text-driver-car">
                        {currentDriver.carBrand} • {currentDriver.carNumber}
                      </p>
                    </div>
                    <div className={`px-4 py-2 rounded-full inline-block font-medium ${
                      currentDriver.online 
                        ? "bg-green-100 text-green-800" 
                        : "bg-gray-100 text-gray-800"
                    }`}>
                      <i className={`fas fa-circle mr-1 ${
                        currentDriver.online ? "text-green-500 animate-pulse" : "text-gray-500"
                      }`}></i>
                      {currentDriver.online ? "В сети" : "Не в сети"}
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500">Зарегистрируйтесь, чтобы начать работу</p>
                )}
              </div>
              
              {currentDriver && (
                <div className="space-y-4 mt-6">
                  <button 
                    onClick={toggleDriverStatus}
                    className={`w-full py-3 rounded-xl font-semibold transition-colors ${
                      currentDriver.online
                        ? "bg-red-500 text-white hover:bg-red-600"
                        : "bg-green-500 text-white hover:bg-green-600"
                    }`}
                    data-testid="button-toggle-status"
                  >
                    <i className={`fas ${currentDriver.online ? "fa-pause" : "fa-play"} mr-2`}></i>
                    {currentDriver.online ? "Завершить смену" : "Начать работу"}
                  </button>
                  
                  {/* Earnings Today */}
                  <div className="bg-gray-50 rounded-xl p-4">
                    <h5 className="font-medium text-gray-700 mb-2">Заработок сегодня</h5>
                    <div className="text-2xl font-bold text-green-600" data-testid="text-earnings">0 ₽</div>
                    <div className="text-sm text-gray-500 mt-1" data-testid="text-trips-count">0 поездок</div>
                  </div>
                </div>
              )}
            </div>

            {/* Rating Card */}
            {currentDriver && (
              <div className="bg-white rounded-2xl card-shadow p-6">
                <h4 className="font-semibold text-gray-800 mb-4">Ваш рейтинг</h4>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-500 mb-2" data-testid="text-driver-rating">
                    {currentDriver.rating}
                  </div>
                  <div className="flex justify-center space-x-1 mb-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <i 
                        key={star}
                        className={`fas fa-star ${
                          star <= Math.floor(parseFloat(currentDriver.rating)) 
                            ? "text-yellow-400" 
                            : "text-gray-300"
                        }`}
                      ></i>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    на основе {currentDriver.totalRatings} оценок
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Trip Requests */}
        {currentDriver && currentDriver.online && (
          <TripRequests 
            bookings={pendingBookings} 
            currentDriver={currentDriver}
            onBookingUpdate={() => refetchBookings()}
          />
        )}

        {/* Active Trips */}
        <div className="mt-8 bg-white rounded-2xl card-shadow-lg p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-semibold text-gray-800">Активные поездки</h3>
            <button 
              onClick={() => refetchBookings()}
              className="text-taxi-purple hover:text-taxi-purple-dark transition-colors"
              data-testid="button-refresh-trips"
            >
              <i className="fas fa-refresh mr-1"></i>Обновить
            </button>
          </div>
          
          <div className="space-y-4" data-testid="container-active-trips">
            {activeBookings.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-route text-2xl text-gray-400"></i>
                </div>
                <p className="text-gray-500 text-lg">У вас нет активных поездок</p>
                <p className="text-gray-400 text-sm mt-2">Принимайте заявки выше, чтобы начать поездку</p>
              </div>
            ) : (
              activeBookings.map((booking) => (
                <div 
                  key={booking.id} 
                  className="border-2 border-green-200 bg-green-50 rounded-xl p-6"
                  data-testid={`card-active-trip-${booking.id}`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white font-bold">
                        <span>{booking.clientName.charAt(0)}</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{booking.clientName}</h4>
                        <p className="text-sm text-gray-600">{booking.clientPhone}</p>
                      </div>
                    </div>
                    {booking.estimatedPrice && (
                      <div className="text-right">
                        <div className="text-lg font-bold text-green-600">{booking.estimatedPrice} ₽</div>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid md:grid-cols-2 gap-4 mb-4 text-sm">
                    <div>
                      <p className="text-gray-600">
                        <i className="fas fa-circle text-green-500 mr-2"></i>
                        Откуда: <span className="font-medium">{booking.fromAddress}</span>
                      </p>
                      <p className="text-gray-600 mt-1">
                        <i className="fas fa-circle text-red-500 mr-2"></i>
                        Куда: <span className="font-medium">{booking.toAddress}</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">Время подачи: <span className="font-medium">{booking.bookingTime}</span></p>
                    </div>
                  </div>
                  
                  <button 
                    onClick={async () => {
                      try {
                        await apiRequest('PATCH', `/api/bookings/${booking.id}/complete`, {});
                        refetchBookings();
                        toast({
                          title: "Поездка завершена",
                          description: "Спасибо за работу!",
                        });
                      } catch (error) {
                        toast({
                          title: "Ошибка",
                          description: "Не удалось завершить поездку",
                          variant: "destructive",
                        });
                      }
                    }}
                    className="w-full bg-green-500 text-white py-3 rounded-xl hover:bg-green-600 transition-colors font-semibold"
                    data-testid={`button-complete-trip-${booking.id}`}
                  >
                    <i className="fas fa-check mr-2"></i>Завершить поездку
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
