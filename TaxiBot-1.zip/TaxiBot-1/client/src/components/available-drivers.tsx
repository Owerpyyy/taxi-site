import { useQuery } from "@tanstack/react-query";
import { type Driver } from "@shared/schema";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

const getFuelIcon = (fuelType: string) => {
  const icons: Record<string, string> = {
    'petrol': '⛽',
    'diesel': '🛢️',
    'propane': '🔥',
    'methane': '💨',
    'electric': '🔋'
  };
  return icons[fuelType] || '⛽';
};

const getFuelName = (fuelType: string) => {
  const names: Record<string, string> = {
    'petrol': 'Бензин',
    'diesel': 'Дизель',
    'propane': 'Пропан',
    'methane': 'Метан',
    'electric': 'Электро'
  };
  return names[fuelType] || 'Бензин';
};

export default function AvailableDrivers() {
  const { data: drivers = [], refetch } = useQuery<Driver[]>({
    queryKey: ["/api/drivers/online"],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      const message = JSON.parse(lastMessage);
      if (["driver_registered", "driver_status_changed"].includes(message.type)) {
        refetch();
      }
    }
  }, [lastMessage, refetch]);

  return (
    <div className="bg-white rounded-2xl card-shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-gray-800">Доступные водители</h3>
        <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
          <i className="fas fa-circle text-green-500 mr-1 animate-pulse"></i>
          <span data-testid="text-online-drivers-count">{drivers.length}</span> онлайн
        </div>
      </div>
      
      <div className="space-y-4" data-testid="container-available-drivers">
        {drivers.length === 0 ? (
          <p className="text-gray-500 text-center py-8">Нет доступных водителей</p>
        ) : (
          drivers.map((driver) => (
            <div 
              key={driver.id}
              className="driver-card-hover border-2 border-gray-100 rounded-xl p-4 hover:border-taxi-purple transition-all duration-300 cursor-pointer"
              data-testid={`card-driver-${driver.id}`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-taxi-purple rounded-full flex items-center justify-center text-white font-bold">
                    <span data-testid={`text-driver-initial-${driver.id}`}>
                      {driver.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800" data-testid={`text-driver-name-${driver.id}`}>
                      {driver.name}
                    </h4>
                    <p className="text-sm text-gray-600" data-testid={`text-driver-car-${driver.id}`}>
                      {driver.carBrand} • {driver.carColor}
                    </p>
                    <p className="text-xs text-gray-500" data-testid={`text-driver-plate-${driver.id}`}>
                      {driver.carNumber}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center text-green-600 text-sm font-medium mb-1">
                    <i className="fas fa-star text-yellow-400 mr-1"></i>
                    <span data-testid={`text-driver-rating-${driver.id}`}>{driver.rating}</span>
                  </div>
                  <div className="text-xs text-gray-500 flex items-center">
                    <span className="mr-1">{getFuelIcon(driver.fuelType)}</span>
                    <span data-testid={`text-driver-fuel-${driver.id}`}>
                      {getFuelName(driver.fuelType)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
