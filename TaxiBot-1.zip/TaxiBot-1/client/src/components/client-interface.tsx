import BookingForm from "./booking-form";
import AvailableDrivers from "./available-drivers";
import { useQuery } from "@tanstack/react-query";
import { type Booking } from "@shared/schema";
import { useWebSocket } from "@/hooks/use-websocket";
import { useEffect } from "react";

export default function ClientInterface() {
  const { data: bookings = [], refetch: refetchBookings } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  const { lastMessage } = useWebSocket();

  useEffect(() => {
    if (lastMessage) {
      const message = JSON.parse(lastMessage);
      if (["new_booking", "booking_accepted", "booking_completed", "booking_deleted"].includes(message.type)) {
        refetchBookings();
      }
    }
  }, [lastMessage, refetchBookings]);

  const activeBookings = bookings.filter(booking => 
    booking.status === "pending" || booking.status === "accepted" || booking.status === "in_progress"
  );

  return (
    <div className="container mx-auto px-4 py-8 animate-fadeIn">
      <div className="max-w-6xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">Заказать такси</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Быстрое и комфортное передвижение по городу. Выберите водителя и отправляйтесь в путь!
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <BookingForm />
          </div>

          {/* Available Drivers & Pricing */}
          <div className="space-y-6">
            <AvailableDrivers />
            
            {/* Pricing Estimate */}
            <div className="bg-gradient-to-br from-taxi-purple to-taxi-purple-dark text-white rounded-2xl p-6">
              <h4 className="font-semibold mb-4">Примерная стоимость</h4>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Базовый тариф</span>
                  <span data-testid="text-base-price">150 ₽</span>
                </div>
                <div className="flex justify-between">
                  <span>За километр</span>
                  <span data-testid="text-per-km-price">25 ₽/км</span>
                </div>
                <hr className="border-white border-opacity-30" />
                <div className="flex justify-between font-bold text-lg">
                  <span>Итого</span>
                  <span data-testid="text-total-price">280 ₽</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Client Bookings */}
        <div className="mt-12 bg-white rounded-2xl card-shadow-lg p-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-semibold text-gray-800">Мои заказы</h3>
            <button 
              onClick={() => refetchBookings()}
              className="text-taxi-purple hover:text-taxi-purple-dark transition-colors"
              data-testid="button-refresh-bookings"
            >
              <i className="fas fa-refresh mr-1"></i>Обновить
            </button>
          </div>
          
          <div className="space-y-4" data-testid="container-client-bookings">
            {activeBookings.length === 0 ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="fas fa-taxi text-2xl text-gray-400"></i>
                </div>
                <p className="text-gray-500 text-lg">У вас пока нет активных заказов</p>
                <p className="text-gray-400 text-sm mt-2">Заполните форму выше, чтобы заказать такси</p>
              </div>
            ) : (
              activeBookings.map((booking) => (
                <div 
                  key={booking.id} 
                  className={`border-2 rounded-xl p-6 ${
                    booking.status === "accepted" 
                      ? "border-green-200 bg-green-50" 
                      : booking.status === "in_progress"
                      ? "border-blue-200 bg-blue-50"
                      : "border-yellow-200 bg-yellow-50"
                  }`}
                  data-testid={`card-booking-${booking.id}`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${
                        booking.status === "accepted" 
                          ? "bg-green-500 text-white" 
                          : booking.status === "in_progress"
                          ? "bg-blue-500 text-white"
                          : "bg-yellow-500 text-white"
                      }`}>
                        <i className="fas fa-car"></i>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">
                          {booking.status === "accepted" ? "Поездка принята" : 
                           booking.status === "in_progress" ? "Поездка в процессе" : "Ожидание водителя"}
                        </h4>
                        {booking.driverId && (
                          <p className="text-sm text-gray-600">Водитель назначен</p>
                        )}
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      booking.status === "accepted" 
                        ? "bg-green-500 text-white" 
                        : booking.status === "in_progress"
                        ? "bg-blue-500 text-white"
                        : "bg-yellow-500 text-white"
                    }`}>
                      {booking.status === "accepted" ? "Принято" : 
                       booking.status === "in_progress" ? "В пути" : "Ожидание"}
                    </span>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-600">
                        Откуда: <span className="font-medium" data-testid={`text-from-${booking.id}`}>{booking.fromAddress}</span>
                      </p>
                      <p className="text-gray-600">
                        Куда: <span className="font-medium" data-testid={`text-to-${booking.id}`}>{booking.toAddress}</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-gray-600">
                        Время: <span className="font-medium" data-testid={`text-time-${booking.id}`}>{booking.bookingTime}</span>
                      </p>
                      {booking.estimatedPrice && (
                        <p className="text-gray-600">
                          Стоимость: <span className="font-medium" data-testid={`text-price-${booking.id}`}>{booking.estimatedPrice} ₽</span>
                        </p>
                      )}
                    </div>
                  </div>
                  {booking.status === "accepted" && (
                    <div className="mt-4 flex space-x-3">
                      <button className="flex-1 bg-white border border-green-500 text-green-600 py-2 rounded-lg hover:bg-green-50 transition-colors"
                              data-testid={`button-call-driver-${booking.id}`}>
                        <i className="fas fa-phone mr-2"></i>Позвонить водителю
                      </button>
                      <button className="flex-1 bg-green-500 text-white py-2 rounded-lg hover:bg-green-600 transition-colors"
                              data-testid={`button-track-${booking.id}`}>
                        <i className="fas fa-map-marker-alt mr-2"></i>Отследить
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
