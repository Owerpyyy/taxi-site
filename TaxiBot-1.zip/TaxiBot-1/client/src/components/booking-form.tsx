import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "@shared/schema";
import { type InsertBooking } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function BookingForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertBooking>({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      fromAddress: "",
      toAddress: "",
      bookingDate: new Date().toISOString().split('T')[0],
      bookingTime: new Date().toTimeString().slice(0, 5),
      clientName: "",
      clientPhone: "",
    },
  });

  const createBookingMutation = useMutation({
    mutationFn: async (data: InsertBooking) => {
      const response = await apiRequest('POST', '/api/bookings', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      form.reset({
        fromAddress: "",
        toAddress: "",
        bookingDate: new Date().toISOString().split('T')[0],
        bookingTime: new Date().toTimeString().slice(0, 5),
        clientName: "",
        clientPhone: "",
      });
      toast({
        title: "Заказ создан!",
        description: "Ожидайте подтверждения от водителя.",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось создать заказ. Попробуйте снова.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBooking) => {
    createBookingMutation.mutate(data);
  };

  return (
    <div className="bg-white rounded-2xl card-shadow-lg p-8">
      <div className="flex items-center mb-6">
        <div className="bg-taxi-purple bg-opacity-10 p-3 rounded-xl mr-4">
          <i className="fas fa-map-marker-alt text-taxi-purple text-xl"></i>
        </div>
        <h3 className="text-2xl font-semibold text-gray-800">Новый заказ</h3>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-booking">
          {/* Address Inputs */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="fromAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-circle text-green-500 mr-2"></i>Откуда
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Адрес подачи"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-from-address"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="toAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-circle text-red-500 mr-2"></i>Куда
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Адрес назначения"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-to-address"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Date & Time */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="bookingDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-calendar text-taxi-purple mr-2"></i>Дата
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="date"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-booking-date"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="bookingTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-clock text-taxi-purple mr-2"></i>Время
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="time"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-booking-time"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Contact Information */}
          <div className="grid md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="clientName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-user text-taxi-purple mr-2"></i>Ваше имя
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="Введите имя"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-client-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="clientPhone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center text-sm font-semibold text-gray-700">
                    <i className="fas fa-phone text-taxi-purple mr-2"></i>Телефон
                  </FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="tel"
                      placeholder="+7 (999) 123-45-67"
                      className="px-4 py-4 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-taxi-purple focus:border-transparent input-focus transition-all duration-300"
                      data-testid="input-client-phone"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <Button
            type="submit"
            disabled={createBookingMutation.isPending}
            className="w-full gradient-bg text-white py-4 rounded-xl font-semibold text-lg hover:opacity-90 transition-all duration-300 shadow-lg transform hover:scale-105"
            data-testid="button-submit-booking"
          >
            <i className="fas fa-paper-plane mr-2"></i>
            {createBookingMutation.isPending ? "Создание заказа..." : "Заказать такси"}
          </Button>
        </form>
      </Form>
    </div>
  );
}
