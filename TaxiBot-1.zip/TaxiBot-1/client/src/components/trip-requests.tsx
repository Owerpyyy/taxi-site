import { type Booking, type Driver } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TripRequestsProps {
  bookings: Booking[];
  currentDriver: Driver;
  onBookingUpdate: () => void;
}

export default function TripRequests({ bookings, currentDriver, onBookingUpdate }: TripRequestsProps) {
  const { toast } = useToast();

  const acceptBookingMutation = useMutation({
    mutationFn: async (bookingId: string) => {
      const response = await apiRequest('PATCH', `/api/bookings/${bookingId}/accept`, {
        driverId: currentDriver.id,
      });
      return response.json();
    },
    onSuccess: () => {
      onBookingUpdate();
      toast({
        title: "Заявка принята!",
        description: "Клиент получил уведомление.",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка",
        description: "Не удалось принять заявку",
        variant: "destructive",
      });
    },
  });

  const handleAcceptBooking = (bookingId: string) => {
    acceptBookingMutation.mutate(bookingId);
  };

  return (
    <div className="mt-12 bg-white rounded-2xl card-shadow-lg p-8">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-2xl font-semibold text-gray-800">Заявки на поездки</h3>
        <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
          <span data-testid="text-pending-requests-count">{bookings.length}</span> новых заявки
        </div>
      </div>
      
      <div className="space-y-4" data-testid="container-trip-requests">
        {bookings.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-clipboard-list text-2xl text-gray-400"></i>
            </div>
            <p className="text-gray-500 text-lg">Новых заявок пока нет</p>
            <p className="text-gray-400 text-sm mt-2">Заявки будут появляться здесь автоматически</p>
          </div>
        ) : (
          bookings.map((booking) => (
            <div 
              key={booking.id} 
              className="border-2 border-blue-200 bg-blue-50 rounded-xl p-6 animate-slideUp"
              data-testid={`card-trip-request-${booking.id}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                    <span data-testid={`text-client-initial-${booking.id}`}>
                      {booking.clientName.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800" data-testid={`text-client-name-${booking.id}`}>
                      {booking.clientName}
                    </h4>
                    <p className="text-sm text-gray-600" data-testid={`text-client-phone-${booking.id}`}>
                      {booking.clientPhone}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  {booking.estimatedPrice && (
                    <div className="text-lg font-bold text-green-600" data-testid={`text-estimated-price-${booking.id}`}>
                      {booking.estimatedPrice} ₽
                    </div>
                  )}
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4 mb-4 text-sm">
                <div>
                  <p className="text-gray-600">
                    <i className="fas fa-circle text-green-500 mr-2"></i>
                    Откуда: <span className="font-medium" data-testid={`text-from-address-${booking.id}`}>
                      {booking.fromAddress}
                    </span>
                  </p>
                  <p className="text-gray-600 mt-1">
                    <i className="fas fa-circle text-red-500 mr-2"></i>
                    Куда: <span className="font-medium" data-testid={`text-to-address-${booking.id}`}>
                      {booking.toAddress}
                    </span>
                  </p>
                </div>
                <div>
                  <p className="text-gray-600">
                    Время подачи: <span className="font-medium" data-testid={`text-requested-time-${booking.id}`}>
                      {booking.bookingTime}
                    </span>
                  </p>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <button 
                  onClick={() => handleAcceptBooking(booking.id)}
                  disabled={acceptBookingMutation.isPending}
                  className="flex-1 bg-green-500 text-white py-3 rounded-xl hover:bg-green-600 transition-colors font-semibold disabled:opacity-50"
                  data-testid={`button-accept-${booking.id}`}
                >
                  <i className="fas fa-check mr-2"></i>
                  {acceptBookingMutation.isPending ? "Принимаю..." : "Принять заказ"}
                </button>
                <button 
                  className="flex-1 bg-gray-300 text-gray-700 py-3 rounded-xl hover:bg-gray-400 transition-colors font-semibold"
                  data-testid={`button-decline-${booking.id}`}
                >
                  <i className="fas fa-times mr-2"></i>Отклонить
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
