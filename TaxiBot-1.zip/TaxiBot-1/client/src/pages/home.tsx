import { useState } from "react";
import ClientInterface from "@/components/client-interface";
import DriverInterface from "@/components/driver-interface";

export default function Home() {
  const [activeInterface, setActiveInterface] = useState<"client" | "driver">("client");

  return (
    <div className="min-h-screen bg-gray-50 font-inter antialiased">
      {/* Header */}
      <header className="gradient-bg text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="bg-white bg-opacity-20 p-2 rounded-xl">
                <i className="fas fa-taxi text-2xl"></i>
              </div>
              <div>
                <h1 className="text-3xl font-bold">TaxiPro</h1>
                <p className="text-purple-100 text-sm">Быстро и надежно</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => setActiveInterface("client")}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 shadow-lg ${
                  activeInterface === "client"
                    ? "bg-white text-taxi-purple"
                    : "bg-transparent border-2 border-white hover:bg-white hover:text-taxi-purple"
                }`}
                data-testid="button-client-interface"
              >
                <i className="fas fa-user mr-2"></i>Клиент
              </button>
              <button
                onClick={() => setActiveInterface("driver")}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 ${
                  activeInterface === "driver"
                    ? "bg-white text-taxi-purple shadow-lg"
                    : "bg-transparent border-2 border-white hover:bg-white hover:text-taxi-purple"
                }`}
                data-testid="button-driver-interface"
              >
                <i className="fas fa-car mr-2"></i>Водитель
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Interface Content */}
      {activeInterface === "client" ? <ClientInterface /> : <DriverInterface />}
    </div>
  );
}
